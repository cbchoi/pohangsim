__all__ = ['check', 'clock', 'core_component', 
			'family','garbage_truck', 'garbagecan', 'government', 
			'human', 'job']