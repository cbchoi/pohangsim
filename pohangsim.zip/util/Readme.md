#-----------CASE GENERATOR-------------#
